module mavenproject1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens mavenproject1 to javafx.fxml;
    exports mavenproject1;
}
