package mavenproject1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

public class SecondaryController implements Initializable{

    @FXML
    private ChoiceBox<String> myDayChoice;
    @FXML
    private ChoiceBox<String> myTimeChoice;
    @FXML
    private ChoiceBox<String> myEndTimeChoice;
    
    @FXML
    private TextField myDescription;
    
    private String[] days = {"monday", "tuesday","wednesday","thursday","friday"};
    
    private String[] times = {"9:00", "10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00"};
    
    
    
    
    
    @FXML
    private void switchToPrimary() throws IOException {
        //App.setRoot("primary");
    }
    
    @FXML
    private void addNewClass() throws IOException {
        String d = myDayChoice.getValue();
        String t = myTimeChoice.getValue();
        String et = myEndTimeChoice.getValue();
        String desc = myDescription.getText();
        App.setDay(d,t,et,desc);
        
        
//        App.setRoot("primary");
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        myDayChoice.getItems().addAll(days);
        
        
        myTimeChoice.getItems().addAll(times);
        myEndTimeChoice.getItems().addAll(times);
       
    }
    
    
    
    
}