package mavenproject1;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


public class PrimaryController implements Initializable{
    

    @FXML
    private ChoiceBox<String> addStartTimeChoice;
    @FXML
    private ChoiceBox<String> addDayChoice;
    @FXML
    private ChoiceBox<String> addEndTimeChoice;
    @FXML
    private ChoiceBox<String> removeStartTimeChoice;
    @FXML
    private ChoiceBox<String> removeDayChoice;
    @FXML
    private ChoiceBox<String> removeEndTimeChoice;
    
    @FXML 
    private Label exceptionLabel;
    
    @FXML
    private TextField addDescription;
    

    
    private String[] days = {"monday", "tuesday","wednesday","thursday","friday"};
    
    private String[] times = {"9:00", "10:00","11:00","12:00","13:00","14:00","15:00","16:00","17:00"};
    
    @FXML
    private void submitClass() throws IOException 
    {

        App.submitRequest();
        exceptionLabel.setText(App.getException());
    }
    
    @FXML
    private void addStatus() throws IOException
    {
        String d = addDayChoice.getValue();
        String t = addStartTimeChoice.getValue();
        String et = addEndTimeChoice.getValue();
        String desc = addDescription.getText();
        App.setDay(d,t,et,desc);
        App.changeStatus("add");
        exceptionLabel.setText(App.getException());
    }
    
    @FXML
    private void removeStatus() throws IOException
    {
        String d = removeDayChoice.getValue();
        String t = removeStartTimeChoice.getValue();
        String et = removeEndTimeChoice.getValue();
        String desc = "";
        App.setDay(d,t,et,desc);
        
        App.changeStatus("remove");
        exceptionLabel.setText(App.getException());
    }
    @FXML
    private void display() throws IOException
    {
        
        App.display();
        
    }
   
    
    @FXML
    private void termination() throws IOException
    {
   
        App.terminate();
    }
    

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        addDayChoice.getItems().addAll(days);
        
        
        addStartTimeChoice.getItems().addAll(times);
        addEndTimeChoice.getItems().addAll(times);
        
        removeDayChoice.getItems().addAll(days);
        
        
        removeStartTimeChoice.getItems().addAll(times);
        removeEndTimeChoice.getItems().addAll(times);
        
    }
    
}