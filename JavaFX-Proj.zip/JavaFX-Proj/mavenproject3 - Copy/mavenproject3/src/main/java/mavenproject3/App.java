package mavenproject3;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import static javafx.application.Application.launch;


/**
 * JavaFX App
 */



public class App extends Application 
        
{
    public static void main(String[] args)
    {
        //runs before app is opened
        Client.establishConnection();
        launch(args); 
        //runs when the app closes
        Client.closeConnection();
    }

    private static Scene scene;
    
    
    private static String day = "";
    private static String startTime = "";
    private static String endTime = "";
    private static String desc = "";
    private static String status = "";
    private static String exception = "";
    
    private static boolean dark = false;
    private static int fontSize = 15;

    @Override
    public void start(Stage stage) throws IOException 
    {
        try{
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
        catch(Exception e)
                {
                    e.printStackTrace();
                }
    }

    static void setRoot(String fxml) throws IOException {
       scene.setRoot(loadFXML(fxml));
      
    }

    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }
    
    public static void setDay(String newDay,String newStartTime,String newEndTime,String newDesc)
    {
        day = newDay;
        startTime = newStartTime;
        endTime = newEndTime;
        desc = newDesc;
        
    }
    public static void changeStatus(String newStatus)
    {
        try{
        if(status == "")
        {
            status = newStatus;
            exception = "";
        }
        else
        {
            throw new IncorrectActionException("Value already set");
        }
        }
        catch(IncorrectActionException e)
	{
		exception = e.toString();
                 
	}
     
    }
    
     public static void removeDay(String newDay,String newStartTime,String newEndTime)
    {
        day = newDay;
        startTime = newStartTime;
        endTime = newEndTime;
        
        
        
    }
     public static void display()
    {
        String timetable = "display";
        System.out.println(timetable);
        status = "display";
        submitRequest();
    }
     public static boolean isDark()
    {
        
        return dark;
        
    }
     public static void fontSize(int size)
    {
        fontSize = size;
    }
    public static void checkCredentials(String s, String y) throws IOException
    {
        if("abc".equals(s) && "1111".equals(y))
        {
            setRoot("primary");
        }
        System.out.println(s+y);
    }
    public static int getFontSize()
    {
        
        return fontSize;
        
    }
    
    public static void changeDarkBool(boolean d)
    {
        
        dark = d;
        
    }
     
     public static void terminate()
    {
        
        System.out.println("terminate");
        
        
    }
    public static void submitRequest()
    {
        try{
        if(status != "")
        {
            System.out.println(status + "-" + day + "-" + startTime + "-" + endTime + "-" + desc);
            String message = status + "-" + day + "-" + startTime + "-" + endTime + "-" + desc;
            Client.sendMessage(message);
            status = "";  
            exception = "";
        }
        else
        {
            throw new IncorrectActionException("Value Not Selected");
        }
        }
        catch(IncorrectActionException e)
	{
		exception = e.toString();
		
	}
    }
    public static String getException()
    {
        return exception;
    
    }
}