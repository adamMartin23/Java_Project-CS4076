package mavenproject3;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;


public class LoginController implements Initializable{
    

    
    
    
    @FXML
    private TextField usernameText;
    @FXML
    private TextField passwordText;
    
    @FXML
    private void checkValid() throws IOException
    {
        String u = usernameText.getText();
        String p = passwordText.getText();
        
        App.checkCredentials(u,p);
        
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
    }
    
}