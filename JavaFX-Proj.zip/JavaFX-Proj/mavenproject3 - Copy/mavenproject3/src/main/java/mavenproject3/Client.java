/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mavenproject3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 *
 * @author darad
 */
public class Client 
{
    static InetAddress host;
    static final int PORT = 1234;
    static Socket link = null;
    static BufferedReader in = null;
    static PrintWriter out = null;
    
    static String message,response = null;
    static boolean close = false;
    
    public static void establishConnection()
    {
        try
        {
            host = InetAddress.getLocalHost();
        }
        catch(UnknownHostException e)
        {
            System.out.println("Host ID not found!");
            System.exit(1);
        }
        try
        {
            link = new Socket(host,PORT);
            in = new BufferedReader(new InputStreamReader(link.getInputStream()));
            out = new PrintWriter(link.getOutputStream(),true);
        }
        catch(IOException e)
        {
            e.printStackTrace();
        } 
    }
    
    public static String sendMessage(String _message)
    {
        try
        {
            //System.out.println("Enter message to be sent to server: ");
            message =  _message;
            out.println(message); 		
            response = in.readLine();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }  
        
        return response;
        
    }
    
    public static void closeConnection()
    {
        try 
        {
            System.out.println("\n* Closing connection... *");
            link.close();				//Step 4.
        }
        catch(IOException e)
        {
            System.out.println("Unable to disconnect/close!");
            System.exit(1);
        }
    }
    
    public static void message(String _message)
    {
       
            try 
            {
               host = InetAddress.getLocalHost();
            } 
            catch(UnknownHostException e) 
            {
               System.out.println("Host ID not found!");
               System.exit(1);
            }
           Socket link = null;				
           try 
           {
               link = new Socket(host,PORT);		
               //link = new Socket( "192.168.0.59", PORT);
               BufferedReader in = new BufferedReader(new InputStreamReader(link.getInputStream()));
               PrintWriter out = new PrintWriter(link.getOutputStream(),true);	

               String message = null;
               String response= null;

               System.out.println("Enter message to be sent to server: ");
               message =  _message;
               out.println(message); 		
               response = in.readLine();		
               
           } 
           catch(IOException e)
           {
               e.printStackTrace();
           } 
           finally 
           {
               try 
               {
                   System.out.println("\n* Closing connection... *");
                   link.close();				//Step 4.
               }catch(IOException e)
               {
                   System.out.println("Unable to disconnect/close!");
                   System.exit(1);
               }
           }
    }
}

