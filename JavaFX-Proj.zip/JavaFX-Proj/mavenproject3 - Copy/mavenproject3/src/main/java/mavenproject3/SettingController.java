package mavenproject3;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;


public class SettingController implements Initializable{
    

    
    
    @FXML
    private Label fontLabel;
    @FXML
    private Label darkModeLabel;
    
    @FXML
    private Slider fontSlider;
    
    @FXML
    private Button toggleDark;
    
    @FXML
    private VBox vBox;
    
    public void goBack() throws IOException
    {
        App.setRoot("primary");
        
    }
    public void toggle()
    {
       
        if(!App.isDark())
        {
         
            toggleDark.getScene().getRoot().getStylesheets().add(getClass().getResource("darkMode.css").toString());
            App.changeDarkBool(true);
            
        }
        else
        {
            
            toggleDark.getScene().getRoot().getStylesheets().remove(getClass().getResource("darkMode.css").toString());
            App.changeDarkBool(false);
        
        }
        
    }

    
    

    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        
        fontLabel.setText("Font Size: " + ((App.getFontSize()-10)*3));
        fontLabel.setFont(Font.font("verdana", App.getFontSize()));
        darkModeLabel.setFont(Font.font("verdana", App.getFontSize()));    
        
        
        Label b = new Label();
        
        vBox.getChildren().add(b);
        if(App.isDark())
        {
            b.getParent().getStylesheets().add(getClass().getResource("darkMode.css").toString());
            
        }
        //vBox.getChildren().add(toggleDark);
        fontSlider.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> ov, Number t, Number t1) {
                int a = (int) fontSlider.getValue();
                fontLabel.setText("Font Size: " + Integer.toString(a));
                fontLabel.setFont(Font.font("verdana", ((int)((a/10)+10))));
                darkModeLabel.setFont(Font.font("verdana", ((int)((a/10)+10))));
                App.fontSize((int)((a/10)+10));
            }
        } 

        );
                
        
    }
    
}