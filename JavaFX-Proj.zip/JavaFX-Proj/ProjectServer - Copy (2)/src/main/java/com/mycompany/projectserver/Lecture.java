/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectserver;
import java.time.LocalTime;
/**
 *
 * @author darad
 */
public class Lecture {
    private String description;
    private LocalTime startTime, endTime;
    
    public Lecture(String _description, String _startTime, String _endTime)
    {
        description = _description;
        startTime = LocalTime.parse(_startTime);
        endTime = LocalTime.parse(_endTime);
    }
    
    public static boolean overlap(Lecture lect1, Lecture lect2)
    {
        boolean clash;
        clash = lect1.getStart().isBefore(lect2.getEnd()) || lect1.getEnd().isAfter(lect2.getStart());
        
        return clash;
    }
    
    public static boolean equals(Lecture lect1, Lecture lect2)
    {
        if(lect1.getStart().equals(lect2.getStart()))
        {
            if(lect1.getEnd().equals(lect2.getEnd()))
            {
                //if(lect1.getDesc().equalsIgnoreCase(lect2.getDesc()))
                 return true;
            }
        }
        
        return false;
    }
    
    public String getDesc()
    {
        return description;
    }
    
    public LocalTime getStart()
    {
        return startTime;
    }
    
    public LocalTime getEnd()
    {
        return endTime;
    }
}
