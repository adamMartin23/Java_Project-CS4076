/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectserver;

/**
 *
 * @author darad
 */
public class Timetable {
    private String[][] schedules = new String[5][9];
    private Day[] week;
    private String User;
    
    // message format : (Action-Day-StartTime-EndTime-Description)
    
    public Timetable()
    {
        week = new Day[5];
        
        initTimetable();
    }
    
    public void addClass(String message)
    {
        String[] args = convertMessage(message);
        int day = matchDay(args[1]);
        
        int[] classDuration = matchTime(args[2],args[3]);
        
        for(int i = 0; i < classDuration[2]; i++)
        {
            int open = classDuration[0] - 9;
            schedules[day][open + i] = args[4];
        }
        
        //Lecture lect = new Lecture(args[4],args[2],args[3]);
        //boolean added = week[day].addLect(lect);
        
        //if(added)
        //{
        //    System.out.println("Added Class Successfully.");
        //}
        //else
        //{
        //    System.out.println("Clash. Class already exists at that time.");
        //}
    }
    
    public void removeClass(String message)
    {
        String[] args = convertMessage(message);
        int day = matchDay(args[1]);
        int[] classDuration = matchTime(args[2],args[3]);
        
        for(int i = 0; i < classDuration[2]; i++)
        {
            int open = classDuration[0] - 9;
            if(schedules[day][open + i].equals(args[4]))
            {
                schedules[day][open + i] = "-";
            } else {
                System.out.print("Class not in timetable");
            }
        }
    }
    
    public void displaySchedule()
    {
        for(int i = 0; i < 5; i++)
        {
            for(int j = 0; j < 9; j++)
            {
                System.out.print(schedules[i][j] + " ");
            }
            
            System.out.println();
        }
    }
    
    private int matchDay(String day)
    {
        int val = 0;
        
        switch (day) 
        {
            case "monday":
                val = 0;
                break;
            case "tuesday":
                val = 1;
                break;
            case "wednesday":
                val = 2;
                break;
            case "thursday":
                val = 3;
                break;
            case "friday":
                val = 4;
                break;
            case "saturday":
                val = 5;
                break;
            case "sunday":
                val = 6;
                break;
        }
        
        return val;
    }
    
    private int[] matchTime(String Start, String End)
    {
        int[] classTime = new int[3];
        String delim = ":";
        
        String[] startTime = Start.split(delim);
        String[] endTime = End.split(delim);
        
        int begin = Integer.parseInt(startTime[0]);
        int finish = Integer.parseInt(endTime[0]);
        
        int duration = finish - begin;
        
        classTime[0] = begin;
        classTime[1] = finish;
        classTime[2] = duration;
        
        return classTime;
    }
    
    private String[] convertMessage(String message)
    {
        String delim = "-";
        
        String[] splitString = message.split(delim);
        
        return splitString;
    }
    
    private void initTimetable()
    {
        for(int i = 0; i < 5; i++)
        {
            for(int j = 0; j < 9; j++)
            {
                schedules[i][j] = "-";
            }
        }
        //for(int i = 0; i < 5; i++)
        //{
        //    week[i] = new Day(getDay(i));
        //}
    }
    
    public void setUser(String message)
    {
        String[] args = convertMessage(message);
        String name = args[1];
        User = name;
    }
    
    private String getDay(int day)
    {
        String val = null;
        
        switch (day) 
        {
            case 0:
                val = "monday";
                break;
            case 1:
                val = "tuesday";
                break;
            case 2:
                val = "wednesday";
                break;
            case 3:
                val = "thursday";
                break;
            case 4:
                val = "friday";
                break;
            case 5:
                val = "saturday";
                break;
            case 6:
                val = "sunday";
                break;
        }
        
        return val;
    }
}
