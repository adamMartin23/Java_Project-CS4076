/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projectserver;
import java.util.ArrayList;
/**
 *
 * @author darad
 */
public class Day {
    private String name;
    private ArrayList<Lecture> timeframe; 
    
    public Day(String _name)
    {
        name = _name;
        timeframe = new ArrayList<>();
    }
    
    public boolean addLect(Lecture lect)
    {
        for(Lecture tf : timeframe)
        {
            if(Lecture.overlap(tf, lect))
            {
                return false;
            }
        }
        timeframe.add(lect);
        
        return true;
    }
    
    public boolean removeLect(Lecture lect)
    {
        for(Lecture tf : timeframe)
        {
            if(Lecture.equals(tf, lect))
            {
                timeframe.remove(lect);
                return true;
            }
                
        }
        
        return false;
    }
    
    public String getName()
    {
        return name;
    }
    
}
