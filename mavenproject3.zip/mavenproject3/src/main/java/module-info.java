module mavenproject3 {
    requires javafx.controls;
    requires javafx.fxml;

    opens mavenproject3 to javafx.fxml;
    exports mavenproject3;
}
